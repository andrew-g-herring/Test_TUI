# Test_TUI

Generates red text in the middle of the screen that says "hello"

## Installation

Install Test_TUI with npm:

```bash
  npm install my-project
```

## Usage

```javascript
import myProject from 'my-project';

myProject.start();
```

## License

[MIT](https://choosealicense.com)
